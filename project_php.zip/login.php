<?php

if(isset($_POST['submit']))
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dhiraj";

$name=$_POST['name'];
$password=$_POST['password'];



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
 }
// else{
// $sql="select password from student where email='".$name.";";

// $result_login=$conn->query($sql);
// if($result_login)
// {
	// if($password == $result_login)
	// {
		// header("Location:home.php");
	// }
// }
// else{
	// echo "not able to login";
// }
//}
}
else{
	echo "Need to login";
}

?>

<html>
<style>
* {box-sizing: border-box}

/* Add padding to containers */
.container {
  padding: 16px;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit/register button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity:1;
}


a {
  color: dodgerblue;
}

.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>
<form action="" method="post">
  <div class="container">
    <h1>Register</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>
    <label for="name"><b>Username</b></label>
    <input type="text" placeholder="Enter Email" name="name" required>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter password" name="password" required>

    
    <button type="submit" class="registerbtn" name="submit">Login</button>
  </div>

  <div class="container signin">
    <p>Not have a acoount <a href="show_details.php">Sign up</a>.</p>
  </div>
</form>

</body>
</html>